<?php return array(
    'root' => array(
        'name' => 'project/plugin',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => '7f14847fb758990f93b71c21d5241bac51cf1ce9',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'project/plugin' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => '7f14847fb758990f93b71c21d5241bac51cf1ce9',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
